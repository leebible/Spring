package kr.or.ddit.vo;

import static org.junit.Assert.*;

import org.junit.Test;

public class ProdVOTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
