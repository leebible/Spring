package kr.or.ddit.enumpkg;

public enum ServiceResult {
	OK, FAIL, PKDUPLICATED, INVALIDPASSWORD
}
