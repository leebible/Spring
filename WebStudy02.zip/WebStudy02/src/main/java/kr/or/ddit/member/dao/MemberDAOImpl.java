package kr.or.ddit.member.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import kr.or.ddit.db.ConnectionFactory_HikariCP;
import kr.or.ddit.mybatis.CustomSqlSessionFacotryBuilder;
import kr.or.ddit.vo.MemberVO;

public class MemberDAOImpl implements MemberDAO {
	private SqlSessionFactory factory = CustomSqlSessionFacotryBuilder.getSqlSessionFactory();
	@Override
	public int insertMember(MemberVO member) {
		try (
				SqlSession sqlsession = factory.openSession();
			){
				int cnt = sqlsession.insert("kr.or.ddit.member.dao.MemberDAO.insertMember",member);
				if(cnt>0) sqlsession.commit();
				return cnt;
			}
		}

	@Override
	public List<MemberVO> selectMemberList() {
		try (
			SqlSession sqlsession = factory.openSession();
		){
			return sqlsession.selectList("kr.or.ddit.member.dao.MemberDAO.selectMemberList");
		}
	}

	@Override
	public MemberVO selectMember(String memId) {
		try(
			SqlSession sqlSession = factory.openSession();
		){
			return sqlSession.selectOne("kr.or.ddit.member.dao.MemberDAO.selectMember",memId);
		}
	}
		

	@Override
	public int update(MemberVO member) {
		try (
				SqlSession sqlsession = factory.openSession();
			){
				int cnt = sqlsession.update("kr.or.ddit.member.dao.MemberDAO.update",member);
				if(cnt>0) sqlsession.commit();
				return cnt;
			}
		}

	@Override
	public int delete(String memId) {
		try (
				SqlSession sqlsession = factory.openSession();
			){
				int cnt = sqlsession.update("kr.or.ddit.member.dao.MemberDAO.delete",memId);
				if(cnt>0) sqlsession.commit();
				return cnt;
			}
		}

}


















